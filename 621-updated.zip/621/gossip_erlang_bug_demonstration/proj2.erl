-module(proj2).
-export([
    fuzzy_ball/2,
    minmax/2,
    minmax_l/5
]).

fuzzy_ball(Id, Nodes, Acc) ->
    S = lists:min([Id-1, 3]),
    if length(Acc) < S ->
        NAcc = Acc ++ [{K, dict:fetch(K, Nodes)} || K <- dict:fetch_keys(Nodes), K < Id, random:uniform() =< 0.5],
        fuzzy_ball(Id, Nodes, NAcc);
    true ->
        Acc
    end.

fuzzy_ball(Id, Nodes) ->
    fuzzy_ball(Id, Nodes, []).

minmax(Data, init) ->
    Frag = dict:fetch(fragments, Data),
    Min  = lists:min([lists:min(element(2, F)) || F <- Frag]),
    Max  = lists:max([lists:max(element(2, F)) || F <- Frag]),
    dict:store(min, Min, dict:store(max, Max, Data));
minmax(Data, send) ->
    {dict:fetch(min, Data), dict:fetch(max, Data)};
minmax(Data, view) ->
    minmax(Data, send);
minmax(Data, Message) ->
    My_Min = dict:fetch(min, Data),
    My_Max = dict:fetch(max, Data),
    Mg_Min = element(1, Message),
    Mg_Max = element(2, Message),

    Ut_Min = if My_Min < Mg_Min -> My_Min; true -> Mg_Min end,
    Ut_Max = if My_Max > Mg_Max -> My_Max; true -> Mg_Max end,
    dict:store(min, Ut_Min, dict:store(max, Ut_Max, Data)).

minmax_l(Main, Nodes, Fragments, _Neighbors, init) ->
    Min = lists:min([lists:min(element(2, dict:fetch(K, Fragments))) || K <- dict:fetch_keys(Fragments)]),
    Max = lists:max([lists:max(element(2, dict:fetch(K, Fragments))) || K <- dict:fetch_keys(Fragments)]),
    io:format("Actual Min: ~p~n", [Min]),
    io:format("Actual Max: ~p~n", [Max]),
    minmax_l(Main, Nodes, Min, Max).

minmax_l(Main, Nodes, Min, Max) ->
    receive
        {_Node, 1, I, round, Data} ->
            io:format("Step: ~p~n", [I]),
            DMin = element(1, Data),
            DMax = element(2, Data),
            if DMin == Min, DMax == Max ->
                io:format("Converged to actual min/max in ~p steps~n", [I]),
                Main   ! continue;
            true ->
                minmax_l(Main, Nodes, Min, Max)
            end;
        _ ->
            minmax_l(Main, Nodes, Min, Max)
    end.
