-module(gossip).
-export([start/6, gossip_node/3]).
    
start(N, M, P, Topology, Func, Listener) ->
    io:format("====================~n"),
    io:format("Spawning ~p nodes~n", [N]),
    Nodes     = dict:from_list([{I, spawn(gossip, gossip_node, [I, P, Func])} || I <- lists:seq(1, N)]),

    io:format("Creating ~p fragments~n", [M]),
    Fragments = dict:from_list([
        {I, {I, [random:uniform(256) + random:uniform() || _ <- lists:seq(1, random:uniform(4))]}} ||
        I <- lists:seq(1, M)
    ]),

    io:format("Building the fragment set~n"),
    FragSet = make_frag_sets(Fragments, N),
    
    io:format("Building the neighbor mapping~n"),
    SgNeighbors = dict:from_list([{I, Topology(I, Nodes)} || I <- lists:seq(1, N)]),
    BiNeighbors = bidirectional(N, Nodes, SgNeighbors),
    Neighbors = dict:from_list([
        {K, sets:to_list(sets:from_list(dict:fetch(K, BiNeighbors)))}
        || K <- dict:fetch_keys(BiNeighbors)
    ]),
    
    io:format("Spawning the listener thread~n"),
    Main = self(),
    LPro = spawn(fun() -> Listener(Main, Nodes, Fragments, Neighbors, init) end),
    io:format("====================~n"),

    [dict:fetch(K, Nodes) ! {
            LPro, 
            dict:fetch(K, FragSet), 
            dict:fetch(K, Neighbors)
    } || K <- dict:fetch_keys(Nodes)],
    block().

make_frag_sets(Frags, N) ->
    S = dict:size(Frags),
    make_frag_sets(Frags, 1, random:uniform(S), S, N, S, 
        dict:from_list([{I, []} || I <- lists:seq(1, N)])
    ).

make_frag_sets(_Frags, _I, _J, 0, _N, _S, FragSet) -> FragSet;
make_frag_sets( Frags,  I,  J, K,  N,  S, FragSet) ->
    NI = if (I+1) > N -> 1; true -> I+1 end,
    NJ = if (J+1) > S -> 1; true -> J+1 end,
    make_frag_sets(Frags, NI, NJ, K-1, N, S, dict:append(I, dict:fetch(J, Frags), FragSet)).

bidirectional(_K, _List, 0, _Nodes, Neighbors) -> Neighbors;
bidirectional( K,  List, L,  Nodes, Neighbors) ->
    {Id, _} = lists:nth(L, List),
    bidirectional(K, List, L-1, Nodes, dict:append(Id, {K, dict:fetch(K, Nodes)}, Neighbors)).

bidirectional(0, _Nodes, Neighbors) -> Neighbors;
bidirectional(K,  Nodes, Neighbors) ->
    List = dict:fetch(K, Neighbors),
    bidirectional(K-1, Nodes, bidirectional(K, List, length(List), Nodes, Neighbors)).

block() ->
    receive
        continue -> ok;
        _        -> block()
    end.

gossip_node(Id, P, Func) ->
    receive
        {L, Fragments, Neighbors} ->
            SystData = dict:store(fragments, Fragments, 
                       dict:store(neighbors, Neighbors, 
                       dict:new())),
            InitData = Func(SystData, init),
            self() ! round,
            gossip_node(Id, 1, L, P, Func, InitData);
        _ -> 
            gossip_node(Id, P, Func)
    end.

gossip_node(Id, I, L, P, Func, Data) ->
    receive
        round ->
                self() ! round,
                L ! {self(), Id, I, round, Func(Data, view)},
                [N ! {self(), push, Func(Data, send)} || {_,N} <- dict:fetch(neighbors, Data), random:uniform() =< P],
                gossip_node(Id, I+1, L, P, Func, Data);
        stop ->
            done;
        {From, push, Message} ->
            From   ! {pull, Func(Data, send)},
            self() ! {pull, Message},
            gossip_node(Id, I, L, P, Func, Data);
        {pull, Message} ->
            UpdtData = Func(Data, Message),
            gossip_node(Id, I, L, P, Func, UpdtData);
        _ ->
            gossip_node(Id, I, L, P, Func, Data)
    end.

