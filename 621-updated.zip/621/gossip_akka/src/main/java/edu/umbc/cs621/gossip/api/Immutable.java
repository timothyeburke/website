package edu.umbc.cs621.gossip.api;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public interface Immutable<T> {
    public T clone() throws CloneNotSupportedException;
}
