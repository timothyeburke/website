package edu.umbc.cs621.gossip.impl;

import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableMap;
import edu.umbc.cs621.gossip.api.DataProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.List;
import java.util.UUID;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public abstract class FragmentProvider implements DataProvider<List<Fragment>> {
    @Resource
    protected Integer numFragments;

    @Autowired
    protected AutowireCapableBeanFactory beanFactory;

    protected ImmutableMap<UUID, Fragment> fragments;

    @PostConstruct
    public void init() {
        ImmutableMap.Builder<UUID, Fragment> fragmentBuilder = new ImmutableBiMap.Builder<UUID, Fragment>();
        int i; Fragment f; for(i = 0; i < numFragments; i++) {
            f = Fragment.class.cast(beanFactory.createBean(
                Fragment.class,
                AutowireCapableBeanFactory.AUTOWIRE_BY_TYPE,
                false
            ));
            fragmentBuilder.put(f.getId(), f);
        }
        fragments = fragmentBuilder.build();
    }
}
