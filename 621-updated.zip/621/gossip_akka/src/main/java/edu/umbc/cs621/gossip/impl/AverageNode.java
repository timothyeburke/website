package edu.umbc.cs621.gossip.impl;

import edu.umbc.cs621.gossip.api.Node;

import java.util.HashSet;
import java.util.List;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public class AverageNode extends Node<List<Fragment>, Average, Average> {
    private Average average;

    @Override
    public void init() throws Exception {
        Float   total = 0.0f;
        Integer count = 0;
        for (Fragment f : new HashSet<Fragment>(initData)) {
            for(Float d : f.getData()) {
                total += d;
                count += 1;
            }
        }
        average = new Average(total / count);
    }

    @Override
    public Average send() throws Exception {
        return average;
    }

    @Override
    public Average data() throws Exception {
        return average;
    }

    @Override
    public void receive(Average data) throws Exception {
        average = new Average((average.value + data.value) / 2.0f);
    }
}
