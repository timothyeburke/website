package edu.umbc.cs621.gossip.impl;

import com.google.common.collect.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Random;

/**
 * @author Colin Taylor
 * @version 1.0
 */
@Component
@Profile("replica")
public class ReplicaFragmentProvider extends FragmentProvider {

    @Resource
    private Integer numNodes;

    @Autowired
    private Random generator;

    private HashMap<Integer, HashSet<Fragment>> fragmentSets;

    @PostConstruct
    public void init() {
        super.init();

        // Make a copy of the fragment value set
        List<Fragment> values = Lists.newArrayList(fragments.values());

        // Generate empty fragment sets for each node
        // Actually use sets in this case, to make sure that a given node
        // doesn't have additional copies of an identical fragment. We
        // want to replicate across the nodes, not within them.
        fragmentSets = new HashMap<Integer, HashSet<Fragment>>();
        int i; for (i = 0; i < numNodes; i++) fragmentSets.put(i, new HashSet<Fragment>());

        // Start somewhere randomly in the set of nodes, and keep sampling
        // fragments until each fragment has been assigned to at least one node
        HashSet<Fragment> used = new HashSet<Fragment>();
        int j = generator.nextInt(numNodes);
        while (used.size() < values.size()) {
            fragmentSets.get(j).add(values.get(generator.nextInt(values.size())));
            j = j++ % numNodes;
        }
    }

    @Override
    public List<Fragment> getData(Integer id) {
        return Lists.newArrayList(fragmentSets.get(id));
    }
}
