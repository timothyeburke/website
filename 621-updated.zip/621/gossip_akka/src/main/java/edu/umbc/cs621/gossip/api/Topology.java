package edu.umbc.cs621.gossip.api;

import akka.actor.ActorRef;

import java.util.List;
import java.util.Map;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public abstract class Topology {

    protected Map<Integer, ActorRef> nodes;

    public void setNodes(Map<Integer, ActorRef> nodes) {
        this.nodes = nodes;
    }

    public abstract List<ActorRef> getNeighbors(Integer id);
}
