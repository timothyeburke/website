package edu.umbc.cs621.gossip.impl;

import akka.actor.ActorRef;
import com.google.common.base.Predicate;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Maps;
import edu.umbc.cs621.gossip.api.Topology;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * @author Colin Taylor
 * @version 1.0
 */
@Component
@Profile("fullyConnected")
public class FullyConnectedTopology extends Topology {
    @Override
    public List<ActorRef> getNeighbors(final Integer id) {
        // Return the set of all nodes that is not myself
        return ImmutableList.copyOf(Maps.filterEntries(nodes,
            new Predicate<Map.Entry<Integer, ActorRef>>() {
                @Override
                public boolean apply(Map.Entry<Integer, ActorRef> input) {
                    return (input != null) && input.getKey() != id;
                }
            }
        ).values());
    }
}
