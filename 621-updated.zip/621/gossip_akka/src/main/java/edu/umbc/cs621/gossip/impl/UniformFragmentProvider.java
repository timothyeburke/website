package edu.umbc.cs621.gossip.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

/**
 * @author Colin Taylor
 * @version 1.0
 */
@Component
@Profile("uniform")
public class UniformFragmentProvider extends FragmentProvider {
    @Resource
    private Integer numNodes;

    @Autowired
    private Random generator;

    private HashMap<Integer,List<Fragment>> fragmentSets;

    @PostConstruct
    public void init() {
        // Construct the set of fragments
        super.init();

        // Generate empty fragment lists for each node
        fragmentSets = new HashMap<Integer, List<Fragment>>();
        int i; for(i = 0; i < numNodes; i++) fragmentSets.put(i, new ArrayList<Fragment>());

        // Start somewhere randomly in the set of nodes, and keep looping
        // through until all fragments have been assigned to a node
        int j = generator.nextInt(numNodes);
        for(Fragment f : fragments.values()) {
            fragmentSets.get(j).add(f);
            j = (j + 1) % numNodes;
        }
    }

    @Override
    public List<Fragment> getData(Integer id) {
        return fragmentSets.get(id);
    }
}
