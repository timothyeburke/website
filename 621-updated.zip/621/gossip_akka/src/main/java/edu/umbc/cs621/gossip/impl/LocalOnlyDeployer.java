package edu.umbc.cs621.gossip.impl;

import akka.actor.Deploy;
import akka.actor.LocalScope;
import edu.umbc.cs621.gossip.api.Deployer;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

/**
 * @author Colin Taylor
 * @version 1.0
 */
@Component
@Profile("local")
public class LocalOnlyDeployer implements Deployer {
    private static LocalScope scope;
    static {
        try {
            scope = LocalScope.class.cast(
                LocalScope.class.getMethod("getInstance").invoke(null)
            );
        } catch (Exception ex) {}
    }

    @Override
    public Deploy getDeploy(Integer id) {
        return new Deploy(scope);
    }
}
