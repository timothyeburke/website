package edu.umbc.cs621.gossip.api;

/**
 * A generic message. Defines a message as an immutable, composite object
 * consisting of an identifier, a header and a payload. Used by the gossip
 * protocol to allow pivoting on the header to handle various message
 * semantics with identical payloads.
 *
 * @author Colin Taylor
 * @version 1.0
 */
public class Message<U> {
    /**
     * The message header definition. A statically defined enum provides
     * a variable that can be used in a switch statement similar to the
     * use of atoms in an Erlang guard function. Used to mark a message
     * with the semantic definition of its payload.
     */
    public static enum Header {
        UPDATE,
        SEND,
        DATA,
        REPLY
    }

    /**
     * The message header.
     */
    public final Header header;

    /**
     * The message data payload.
     */
    public final U      payload;

    /**
     * Construct a new message with the given header and payload.
     *
     * @param header  The message header.
     * @param payload The message payload.
     */
    public Message(Header header, U payload) {
        this.header = header;
        this.payload = payload;
    }

    /**
     * Return a string representation of the message.
     * @return A meaningful representation of the message, including its
     *         identifier, header, and payload data.
     */
    public String toString() {
        return String.format("<%s, %s>", header, payload);
    }
}

