package edu.umbc.cs621.gossip.impl;

import edu.umbc.cs621.gossip.api.Node;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public class MedianNode extends Node<List<Fragment>, Median, Median> {
    private Median median;

    @Override
    public void init() throws Exception {
        // Merge together all of the data into a median buffer and weight
        ArrayList<Median> medians = new ArrayList<Median>();
        for(Fragment f : initData) {
            medians.add(new Median(f.getData()));
        }
        if(medians.size() == 1) median = medians.get(0);
        if(medians.size() >= 2) median = medians.get(0).merge(medians.get(1));
        if(medians.size() >  2) {
            int i; for(i = 2; i < medians.size(); i++)
                median = median.merge(medians.get(i));
        }
    }

    @Override
    public Median send() throws Exception {
        return median;
    }

    @Override
    public Median data() throws Exception {
        return median;
    }

    @Override
    public void receive(Median data) throws Exception {
        median = median.merge(data);
    }
}
