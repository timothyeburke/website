package edu.umbc.cs621.gossip.impl;

import edu.umbc.cs621.gossip.api.Immutable;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public class UpdateFragment implements Immutable<UpdateFragment> {
    public final Fragment fragment;


    public UpdateFragment(Fragment fragment) {
        this.fragment = fragment;
    }

    @Override
    public UpdateFragment clone() throws CloneNotSupportedException {
        return new UpdateFragment(fragment);
    }
}
