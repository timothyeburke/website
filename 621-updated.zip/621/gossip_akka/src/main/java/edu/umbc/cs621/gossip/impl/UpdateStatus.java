package edu.umbc.cs621.gossip.impl;

import edu.umbc.cs621.gossip.api.Immutable;

import java.util.List;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public class UpdateStatus implements Immutable<UpdateStatus> {
    public final List<Fragment> fragments;
    public final Boolean updated;

    public UpdateStatus(List<Fragment> fragments, Boolean updated) {
        this.fragments = fragments;
        this.updated   = updated;
    }

    @Override
    public UpdateStatus clone() throws CloneNotSupportedException {
        return new UpdateStatus(fragments, updated);
    }
}
