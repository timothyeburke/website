package edu.umbc.cs621.gossip.impl;

import com.google.common.collect.ImmutableList;
import edu.umbc.cs621.gossip.api.Immutable;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public class Fragment implements Immutable<Fragment> {
    @Resource
    private Integer fragmentSize;

    @Resource
    private Float fragmentMin;

    @Resource
    private Float fragmentMax;

    @Autowired
    private Random generator;

    private UUID id;
    private List<Float> data;

    @PostConstruct
    public void init() {
        id = UUID.randomUUID();
        int s = (generator.nextInt(fragmentSize) + 1);
        ImmutableList.Builder<Float> dataBuilder = new ImmutableList.Builder<Float>();
        int i; for(i = 0; i < s; i++) {
            dataBuilder.add(
                (fragmentMax * generator.nextFloat()) + fragmentMin +  // Value
                (generator.nextBoolean() ? generator.nextFloat() : 0)  // Optional offset
            );
        }
        data = dataBuilder.build();
    }

    public Fragment clone() {
        Fragment f = new Fragment();
        f.setData(this.getData());
        f.setUUID(UUID.fromString(getId().toString()));
        return f;
    }

    public void setUUID(UUID id) {
        this.id = id;
    }

    public UUID getId() {
        return id;
    }

    public void setData(List<Float> data) {
        this.data = data;
    }

    public List<Float> getData() {
        return data;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Fragment fragment = (Fragment) o;
        if (id != null ? !id.equals(fragment.id) : fragment.id != null) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return String.format("%s: %s", id, data);
    }
}
