package edu.umbc.cs621.gossip.impl;

import akka.actor.ActorRef;
import edu.umbc.cs621.gossip.api.Gossip;
import edu.umbc.cs621.gossip.api.Node;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public class MinMaxGossip extends Gossip<List<Fragment>, MinMax<Float>, MinMax<Float>> {
    @Resource
    private Integer numNodes;

    @Autowired
    private Random generator;

    private MinMax<Float> actualMinMax;
    private ActorRef      watchedNode;

    @Override
    public void init() {
        // Calculate the actual minimum and maximum
        // We need this for the update function
        ArrayList<Float> data = new ArrayList<Float>();
        for(List<Fragment> fragments : nodeData) {
            for(Fragment f : fragments) data.addAll(f.getData());
        }
        actualMinMax = new MinMax<Float>(
            Collections.min(data),
            Collections.max(data)
        );
        log.info("Actual Min: {}, Max: {}", actualMinMax.min, actualMinMax.max);

        // Pick a random node to watch
        Integer node = generator.nextInt(numNodes);
        log.info("Watching node {} ({})", node, nodeId.inverse().get(node));
        watchedNode = nodes.get(node);
    }

    @Override
    public Class<? extends Node<List<Fragment>, MinMax<Float>, MinMax<Float>>> nodeType() {
        return MinMaxNode.class;
    }

    @Override
    public boolean update(Integer round, MinMax<Float> data, ActorRef node)
        throws Exception {
        if(node.equals(watchedNode)) {
            if(round % 5 == 0) log.info("Round {}", round);
            if(data.equals(actualMinMax)) {
                log.info("Found actual min/max in {} rounds", round);
                return true;
            } else return false;
        } else return false;
    }
}
