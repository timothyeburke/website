package edu.umbc.cs621.gossip.impl;

import edu.umbc.cs621.gossip.api.Immutable;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public class MinMax<T extends Comparable<T>> implements Immutable<MinMax<T>> {
    public final T min;
    public final T max;

    public MinMax(T min, T max) {
        this.min = min;
        this.max = max;
    }

    public MinMax<T> clone() throws CloneNotSupportedException {
        return new MinMax<T>(min, max);
    }

    public MinMax<T> update(MinMax<T> other) {
        return new MinMax<T>(
            ((other.min.compareTo(min) < 0) ? other.min : min),
            ((other.max.compareTo(max) > 0) ? other.max : max)
        );
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MinMax minMax = (MinMax) o;

        if (max != null ? !max.equals(minMax.max) : minMax.max != null) {
            return false;
        }
        if (min != null ? !min.equals(minMax.min) : minMax.min != null) {
            return false;
        }

        return true;
    }

    public String toString() {
        return String.format("Min: %s, Max: %s", min, max);
    }
}
