package edu.umbc.cs621.gossip.api;

/**
 * A gossip round. Encapsulates a payload of round data with a round
 * identifier, so that this can be unrolled by the parent to get
 * a view of what round an actor is currently in. Defined as an
 * immutable data type, as required by Akka messaging semantics (since
 * this will be sent across the message bus).
 *
 * @author Colin Taylor
 * @version 1.0
 */
public class Round<V> {
    /**
     * The round identifier associated with this round data.
     */
    public final Integer round;
    /**
     * The data associated with this round.
     */
    public final V    data;

    /**
     * Construct a new gossip round.
     *
     * @param round The round identifier for this round.
     * @param data  The data view associated with this round.
     */
    public Round(Integer round, V data) {
        this.round = round;
        this.data  = data;
    }
}
