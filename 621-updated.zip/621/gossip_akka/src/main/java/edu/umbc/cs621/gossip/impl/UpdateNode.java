package edu.umbc.cs621.gossip.impl;

import edu.umbc.cs621.gossip.api.Node;

import java.util.List;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public class UpdateNode extends Node<List<Fragment>, UpdateFragment, UpdateStatus> {
    private Fragment     store;
    private UpdateStatus update;

    @Override
    public void init() throws Exception {
        this.store  = null;
        this.update = new UpdateStatus(initData, false);
    }

    @Override
    public UpdateFragment send() throws Exception {
        return new UpdateFragment(store);
    }

    @Override
    public UpdateStatus data() throws Exception {
        return update;
    }

    @Override
    public void receive(UpdateFragment data) throws Exception {
        if(data.fragment == null) return;
        for(Fragment f : initData) {
            if(f.getId().equals(data.fragment.getId())) {
                store  = data.fragment;
                update = new UpdateStatus(initData, true);
                break;
            }
        }
    }
}
