package edu.umbc.cs621.gossip.impl;

import edu.umbc.cs621.gossip.api.Immutable;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public class Average implements Immutable<Average> {

    public final Float value;

    public Average(Float value) {
        this.value = value;
    }

    @Override
    public Average clone() throws CloneNotSupportedException {
        return new Average(value);
    }

    public String toString() {
        return String.format("Average: %s", value);
    }
}
