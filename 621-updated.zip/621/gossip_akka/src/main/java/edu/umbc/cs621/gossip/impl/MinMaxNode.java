package edu.umbc.cs621.gossip.impl;

import edu.umbc.cs621.gossip.api.Node;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public class MinMaxNode extends Node<List<Fragment>, MinMax<Float>, MinMax<Float>> {
    private MinMax<Float> minMax;

    @Override
    public void init() throws Exception {
        ArrayList<Float> data = new ArrayList<Float>();
        for(Fragment f : new HashSet<Fragment>(initData)) {
            data.addAll(f.getData());
        }
        minMax = new MinMax<Float>(
            Collections.min(data),
            Collections.max(data)
        );
    }

    @Override
    public MinMax<Float> send() throws Exception {
        return minMax;
    }

    @Override
    public MinMax<Float> data() throws Exception {
        return minMax;
    }

    @Override
    public void receive(MinMax<Float> data) throws Exception {
        minMax = minMax.update(data);
    }
}
