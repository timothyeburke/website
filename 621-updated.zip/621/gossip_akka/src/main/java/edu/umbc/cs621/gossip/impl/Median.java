package edu.umbc.cs621.gossip.impl;

import com.google.common.collect.ImmutableList;
import edu.umbc.cs621.gossip.api.Immutable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public class Median implements Immutable<Median> {

    private static Integer evenFlag = 0;

    private static class DataWeight implements Comparable<DataWeight> {
        public final Float   data;
        public final Integer weight;

        public DataWeight(Float data, Integer weight) {
            this.data   = data;
            this.weight = weight;
        }

        @Override
        public int compareTo(DataWeight dataWeight) {
            return data.compareTo(dataWeight.data);
        }
    }

    private final List<Float> data;
    private final Integer     weight;

    public Median(List<Float> data) {
        this(data, 1);
    }

    public Median(List<Float> data, Integer weight) {
        this.data   = data;
        this.weight = weight;
    }

    @Override
    public Median clone() throws CloneNotSupportedException {
        return new Median(ImmutableList.copyOf(data), weight);
    }

    public List<Float> getData() {
        return this.data;
    }

    public Integer getWeight() {
        return this.weight;
    }

    public Float getApproxMedian() {
        // Figure out if we just need the middle one, or to take an average
        Integer size = data.size() * weight;
        ArrayList<Integer> fetchPos = new ArrayList<Integer>();
        if(size % 2 == 0) {
            fetchPos.add((size / 2));
            fetchPos.add((size / 2) + 1);
        } else {
            fetchPos.add(size / 2);
        }

        // Treat it like an average no matter what (element / 1 == element)
        Float total = 0.0f;
        int i, count = 0;
        for(Float d : data) {
            for(i = 0; i < weight; i++) {
                if(fetchPos.contains(count)) total += d;
                count++;
            }
        }
        return total / (float) fetchPos.size();
    }

    public Median merge(Median other) {
        // Make both arrays the same length, by padding with +/- infinity
        int k = (data.size() > other.getData().size()) ? data.size() : other.getData().size();
        ArrayList<Float> mydata = new ArrayList<Float>(data);
        ArrayList<Float> otdata = new ArrayList<Float>(other.getData());

        // Pad, merge and sort the arrays
        ArrayList<DataWeight> merged = new ArrayList<DataWeight>();
        int i, count = 0; for(i = 0; i < k; i++) {
            if(i < mydata.size()) merged.add(new DataWeight(mydata.get(i), weight));
            else {
                merged.add(
                    new DataWeight(
                        (count++ % 2) == 0 ? Float.MIN_VALUE : Float.MAX_VALUE,
                        weight
                    )
                );
            }
        }
        for (i = 0; i < k; i++) {
            if (i < otdata.size()) merged.add(new DataWeight(otdata.get(i), other.getWeight()));
            else {
                merged.add(new DataWeight(
                    (count++ % 2) == 0 ? Float.MIN_VALUE : Float.MAX_VALUE,
                    other.getWeight()
                ));
            }
        }
        Collections.sort(merged);

        // Figure out the combined weight
        Integer wY = weight + other.getWeight();

        // Determine which elements make up the new array
        ArrayList<Integer> items = new ArrayList<Integer>();
        int j; for(j = 0; j < k; j++) {
            if (wY % 2 == 0) {
                items.add((evenFlag % 2 == 0)
                    ? (j * wY) + ((wY + 0) / 2)
                    : (j * wY) + ((wY + 2) / 2)
                );
            } else {
                items.add(
                      (j * wY) + ((wY + 1) / 2)
                );
            }
        }
        evenFlag++; // Alternate between which side of even median to take

        // Find the merged array
        ArrayList<Float> combined = new ArrayList<Float>();
        count = 0;
        for(DataWeight d : merged) {
            for(i = 0; i < d.weight; i++) {
                if(items.contains(count)) combined.add(d.data);
                count++;
            }
        }

        // Return the updated median
        return new Median(ImmutableList.copyOf(combined), wY);
    }
}
