package edu.umbc.cs621.gossip.api;

import akka.actor.ActorRef;
import akka.actor.UntypedActor;
import akka.japi.Procedure;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Random;

/**
 * A gossip node. Provides a generic implementation of a gossip node that
 * can be used to implement the gossip protocol. Handles all messaging
 * semantics required by Akka, and abstracts the interface to four functions
 * with generic behavior to support arbitrary state data.
 *
 * @param <I> The initialization data type. Used to initialize the node with
 *            a specific object.
 * @param <U> The communication data type. Used for all gossip update exchanges.
 *            Data type must be immutable.
 * @param <V> The view data type. Used for parent update notification and
 *            monitoring of the gossip system. Data type must be immutable.
 *
 * @author Colin Taylor
 * @version 1.0
 */
public abstract class Node<I,U extends Immutable<U>,V extends Immutable<V>>
    extends UntypedActor {

    /**
     * The probability that this node will communicate with each of its
     * neighbor nodes. Nicely encapsulates potential sources of failure,
     * because choosing not to communicate with a node and being unable
     * to communicate with a node (due to node failure, network failure,
     * network latency, etc.) are equivalent. This makes the probability
     * of aggregate failure 1 - probability.
     */
    protected Float probability;

    public void setProbability(Float probability) {
        this.probability = probability;
    }

    /**
     * A random generator the node should use for random communication.
     * This breaks out the generator and provides it as a resource configured
     * by Spring, allowing one generator to be configured and shared
     * across the system.
     */
    @Autowired
    protected Random generator;

    /**
     * The set of neighbors with which this node will be communicating.
     */
    protected List<ActorRef> neighbors;

    /**
     * The initialization data object. Provided for the init function so that
     * data can be passed into the node before it is called.
     */
    protected I initData;

    /**
     * Set the initialization data. Must be called before init is run, to
     * guarantee the node has all required data to initialize.
     *
     * @param initData The initialization data for the node.
     */
    public void setInitData(I initData) {
        this.initData = initData;
    }

    /**
     * The current gossip round counter. The actual value is read-only
     * because it is the responsibility of this superclass to maintain
     * the round count (since its actually defining the gossip protocol).
     */
    private Integer round = 0;
    /**
     * Returns the current gossip round.
     * @return The current gossip round.
     */
    protected Integer getRound() {
        return round;
    }

    /**
     * The main execution behavior - e.g. the gossip protocol. Defines
     * a generic gossip system that correctly defines the behavior of
     * this system at an abstract level, using the methods that must
     * be defined when implementing this class (for solving a specific
     * problem).
     */
    protected Procedure<Object> mainLoop = new Procedure<Object>() {
        @Override @SuppressWarnings("unchecked")
        public void apply(Object rawMessage) throws Exception {
            // Only handle the Message type - this gives us a header
            // and a payload so we can pivot on something like the
            // atoms in Erlang
            if (rawMessage instanceof Message) {
                Message<U> message = (Message<U>) rawMessage;
                switch (message.header) {
                    // Start a new gossip round -
                    // randomly communicate with my neighbors and trigger
                    // the next round
                    case SEND:
                        // Let my parent know that I'm starting the next round
                        round++;
                        getContext().parent().tell(
                            new Message<Round<V>>(
                                Message.Header.UPDATE,
                                new Round<V>(round, data().clone())
                            ), getSelf()
                        );

                        // Try to communicate with each neighbor in my set
                        // (was provided by the topology definition)
                        for (ActorRef neighbor : neighbors) {
                            // Communication chance is probabilistic. This
                            // nicely encapsulates all sorts of failures, like
                            // node failure, network communication failure,
                            // partial message failure, etc, into a single
                            // adjustable value.
                            if (generator.nextFloat() > probability) continue;
                            // Send the neighbor my data (which will trigger them)
                            // to send me a REPLY back
                            neighbor.tell(
                                new Message<U>(Message.Header.DATA, send().clone()),
                                getSelf()
                            );
                        }

                        // Put another SEND in my queue, so this happens
                        // perpetually until this actor is halted
                        getSelf().tell(
                            new Message<U>(Message.Header.SEND, null), getSelf()
                        );
                        break;
                    // Handle incoming data as part of a gossip round. Send
                    // a REPLY to ensure that gossip is bidirectional by
                    // convention.
                    case DATA:
                        // Handle the incoming data transmission as a reply from
                        // myself - this is a little hack that makes things
                        // consistent so that all of the processing can happen
                        // in one place
                        getSelf().tell(
                            new Message<U>(
                                Message.Header.REPLY, message.payload
                            ), getSelf()
                        );
                        // Send a REPLY back to my sender with the same data from
                        // me. This is a REPLY so that we don't trigger this
                        // bidirectional method again and cause endless message
                        // sending.
                        getSender().tell(
                            new Message<U>(Message.Header.REPLY, send().clone()), getSelf()
                        );
                        break;
                    // Process incoming data from another node. This should
                    // cause the local state to update.
                    case REPLY:
                        receive(message.payload);
                        break;
                }
            }
            // An invalid message was sent - handle it accordingly
            else { unhandled(rawMessage); }
        }
    };

    /**
     * The main messaging loop of the node / Akka actor. Defines the "init"
     * behavior of the actor - to wait for its set of neighbors. This method
     * will be overridden by the mainLoop once the set is received.
     *
     * @param rawMessage The incoming message.
     * @throws Exception An exception occurred while processing the message.
     */
    @Override @SuppressWarnings("unchecked")
    public void onReceive(Object rawMessage) throws Exception {
        // Wait for a list of neighbors, since the only way for me to
        // get these to each node is to message them to them as
        // a set (since they contain references to themselves). Once
        // this is done, proceed with delayed initialization (which allows
        // you to use the neighbor set at this point), and then use
        // Akka behavior hotswapping to enter the main loop.
        if(rawMessage instanceof List) {
            // Set the list of neighbors from the incoming message
            neighbors = (List<ActorRef>) rawMessage;

            // Initialize and change execution to the main loop
            init();

            getContext().become(mainLoop);

            // Send myself a SEND request, so I start running the gossip
            // protocol
            getSelf().tell(
                new Message<U>(Message.Header.SEND, null), getSelf()
            );
        } else { unhandled(rawMessage); }
    }

    /**
     * The node initialization function. MUST establish the initial
     * state of the node for processing in a gossip system.
     */
    public abstract void init() throws Exception;

    /**
     * The node data sending function. Called when data must be sent
     * to a neighbor node - generic so each implementation can define
     * what value(s) it will need when receiving. Any value sent MUST
     * be IMMUTABLE (this is not easily enforceable and must be by convention).
     *
     * @return The data value to send to a node.
     */
    public abstract U    send() throws Exception;

    /**
     * The node data view function. Called for sending updates to the
     * parent gossip system node, so that the system can monitor the status
     * of its children. Generic so that each implementation can define
     * what value(s) it wants to report back.to the parent, and differs
     * from the send function in case this value needs to be different.
     *
     * @return The data view to report to the parent gossip system node.
     */
    public abstract V    data() throws Exception;

    /**
     * The node data receiving function. Called when data is received
     * via the gossip protocol. MUST update the internal state of the node
     * to reflect incoming data.
     *
     * @param data The incoming data from the gossip communication.
     */
    public abstract void receive(U data) throws Exception;
}
