package edu.umbc.cs621.gossip.impl;

import akka.actor.ActorRef;
import edu.umbc.cs621.gossip.api.Gossip;
import edu.umbc.cs621.gossip.api.Node;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;
import java.util.List;
import java.util.Random;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public class AverageGossip extends Gossip<List<Fragment>, Average, Average> {
    @Resource
    private Integer numNodes;

    @Autowired
    private Random generator;

    private Float    actualAverage;
    private Float    minAverage;
    private Float    maxAverage;
    private Float    percentage;

    private ActorRef watchedNode;

    @Override
    public void init() {
        // Calculate the actual minimum and maximum
        // We need this for the update function
        Float   total = 0.0f;
        Integer count = 0;
        for (List<Fragment> fragments : nodeData) {
            for (Fragment f : fragments) {
                for(Float d : f.getData()) {
                    total += d;
                    count += 1;
                }
            }
        }

        // Calculate the actual average
        actualAverage = total / count;
        log.info("Actual average: {}", actualAverage);

        // Determine an acceptable percentage range for the average
        percentage = 0.01f;
        minAverage = actualAverage - (actualAverage * percentage);
        maxAverage = actualAverage + (actualAverage * percentage);
        log.info("Looking for range {} to {} ({} %)", minAverage, maxAverage, 100 * percentage);

        // Pick a random node to watch
        Integer node = generator.nextInt(numNodes);
        log.info("Watching node {} ({})", node, nodeId.inverse().get(node));
        watchedNode = nodes.get(node);
    }

    @Override
    public Class<? extends Node<List<Fragment>, Average, Average>> nodeType() {
        return AverageNode.class;
    }

    @Override
    public boolean update(Integer round, Average data, ActorRef node)
        throws Exception {
        if(node.equals(watchedNode)) {
            if(round % 5 == 0) log.info("Round {}", round);
            if(data.value >= minAverage && data.value <= maxAverage) {
                log.info(
                    "Found average of {} in {} rounds",
                    data.value, round
                );
                return true;
            } else return false;
        } else return false;
    }
}
