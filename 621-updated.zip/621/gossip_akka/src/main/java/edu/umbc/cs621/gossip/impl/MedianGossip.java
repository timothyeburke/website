package edu.umbc.cs621.gossip.impl;

import akka.actor.ActorRef;
import edu.umbc.cs621.gossip.api.Gossip;
import edu.umbc.cs621.gossip.api.Node;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public class MedianGossip extends Gossip<List<Fragment>, Median, Median> {
    @Resource
    private Integer numNodes;

    @Autowired
    private Random generator;

    private Float actualMedian;
    private Float minMedian;
    private Float maxMedian;
    private Float percentage;

    private ActorRef watchedNode;

    @Override
    public void init() {
        // Calculate the actual median
        ArrayList<Float> data = new ArrayList<Float>();
        for (List<Fragment> fragments : nodeData) {
            for (Fragment f : fragments) data.addAll(f.getData());
        }
        if(data.size() % 2 == 0) {
            actualMedian = (data.get((data.size() / 2)) + data.get((data.size() / 2) + 1)) / 2;
        } else {
            actualMedian = data.get(data.size() / 2);
        }
        log.info("Actual median: {}", actualMedian);

        // Calculate stop threshold - this might be better if we calculated it
        // as within +/- n positions of the actual median
        percentage = 0.1f; // within 10% of actual
        minMedian = actualMedian - (actualMedian * percentage);
        maxMedian = actualMedian + (actualMedian * percentage);
        log.info(
            "Looking for range {} to {} ({} %)", minMedian, maxMedian,
            100 * percentage
        );

        // Pick a random node to watch
        Integer node = generator.nextInt(numNodes);
        log.info("Watching node {} ({})", node, nodeId.inverse().get(node));
        watchedNode = nodes.get(node);
    }

    @Override
    public Class<? extends Node<List<Fragment>, Median, Median>> nodeType() {
        return MedianNode.class;
    }

    @Override
    public boolean update(Integer round, Median data, ActorRef node)
        throws Exception {
        if (node.equals(watchedNode)) {
            if(round % 5 == 0) log.info("Round {}", round);
            Float approxMedian = data.getApproxMedian();
            if( approxMedian >= minMedian &&
                approxMedian <= maxMedian) {
                log.info(
                    "Found median of {} in {} rounds",
                    approxMedian, round
                );
                return true;
            } else if (round == 100) {
                log.info("Did not converge after 100 rounds");
                return true;
            }
            else return false;
        }
        else return false;
    }
}
