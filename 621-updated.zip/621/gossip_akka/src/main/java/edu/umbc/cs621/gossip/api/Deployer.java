package edu.umbc.cs621.gossip.api;

import akka.actor.Deploy;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public interface Deployer {
    public Deploy getDeploy(Integer id);
}
