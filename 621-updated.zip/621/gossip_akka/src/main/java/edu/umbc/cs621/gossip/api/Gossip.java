package edu.umbc.cs621.gossip.api;

import akka.actor.ActorRef;
import akka.actor.PoisonPill;
import akka.actor.Props;
import akka.actor.UntypedActor;
import akka.actor.UntypedActorFactory;
import akka.event.Logging;
import akka.event.LoggingAdapter;
import com.google.common.base.Functions;
import com.google.common.collect.ImmutableBiMap;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import java.util.UUID;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public abstract class Gossip<I,U extends Immutable<U>,V extends Immutable<V>>
    extends UntypedActor {
    @Resource
    private Integer numNodes;

    @Resource
    private Float probability;

    @Autowired
    private Topology topology;

    @Autowired
    private DataProvider<I> dataProvider;

    @Autowired
    private AutowireCapableBeanFactory beanFactory;

    @Autowired
    private Deployer deployer;

    /**
     * A configured logger, for the update function.
     */
    protected LoggingAdapter log = Logging.getLogger(context().system(), this);

    protected ImmutableBiMap<Integer, ActorRef> nodes;
    protected ImmutableBiMap<UUID, Integer>     nodeId;
    protected ImmutableBiMap<UUID, ActorRef>    nodeMap;
    protected ImmutableList<I>                  nodeData;

    private static PoisonPill poisonPill;
    static {
        try {
            poisonPill = PoisonPill.class.cast(
                PoisonPill.class.getMethod("getInstance").invoke(null)
            );
        } catch (Exception ex) {}
    }

    @PostConstruct
    public void setup() {
        // Create mapping builders, since we need to build immutable maps
        // for reference to the nodes. References are possible two ways -
        // by Id and by UUID.
        ImmutableMap.Builder<Integer, ActorRef> nodeBuilder   = new ImmutableMap.Builder<Integer, ActorRef>();
        ImmutableMap.Builder<UUID, Integer>     nodeIdBuilder = new ImmutableMap.Builder<UUID, Integer>();
        ImmutableList.Builder<I>                dataBuilder   = new ImmutableList.Builder<I>();

        // Actually construct the set of nodes, making sure to initialize
        // them in accordance with the defined conventions.
        log.info("Generating {} nodes...", numNodes);
        UUID id; int i; for(i = 0; i < numNodes; i++) {
            final I data = dataProvider.getData(i);
            dataBuilder.add(data);
            id = UUID.randomUUID();
            nodeIdBuilder.put(id, i);
            nodeBuilder.put(
                i,
                getContext().actorOf(new Props(new UntypedActorFactory() {
                    @Override
                    public UntypedActor create() throws Exception {
                        // Use the spring context to actually construct
                        // the node, so it can inherit configuration from
                        // the context.
                        Node<I,U,V> node = nodeType().cast(
                            beanFactory.createBean(
                                nodeType(),
                                AutowireCapableBeanFactory.AUTOWIRE_BY_TYPE,
                                false
                            )
                        );
                        // Make sure the node is given its initialization data
                        node.setInitData(data);
                        node.setProbability(probability);
                        return node;
                    }
                }).withDeploy(deployer.getDeploy(i)), id.toString()
            ));
        }

        // Define the mappings, including a direct mapping from
        // UUID -> ActorRef.
        nodes    = ImmutableBiMap.copyOf(nodeBuilder.build());
        nodeId   = ImmutableBiMap.copyOf(nodeIdBuilder.build());
        nodeMap  = ImmutableBiMap.copyOf(Maps.transformValues(
            nodeId, Functions.forMap(nodes)
        ));
        nodeData = dataBuilder.build();
        log.info("Finished generating nodes");

        // Let the gossip system do any initialization it needs
        init();

        // Now that the full set of nodes exists, initialize the topology
        // and send neighbors to each of the nodes. This will kick off
        // the gossip rounds.
        topology.setNodes(nodes);
        for(i = 0; i < numNodes; i++) {
            nodes.get(i).tell(topology.getNeighbors(i), getSelf());
        }
    }

    /**
     * The main messaging loop of the gossip system. Listens for UPDATE
     * messages from the children "nodes" of the system, to monitor if
     * the system should continue running.
     *
     * @param rawMessage The incoming message to this actor.
     * @throws Exception An exception occurred while processing the message.
     */
    @Override @SuppressWarnings("unchecked")
    public void onReceive(Object rawMessage) throws Exception {
        // Only handle the Message type - this gives us a header
        // and a payload so we can pivot on something like the
        // atoms in Erlang
        if(rawMessage instanceof Message) {
            Message<?> message  = (Message<?>) rawMessage;
            switch (message.header) {
                // An update from a child. Includes a data payload indicating
                // the current state of the child. Sent by every child on
                // each local gossip step, which can be filtered by
                // watching a set of specific child identifiers.
                case UPDATE:
                    // Use the incoming update information to determine if
                    // the gossip system should continue to run. If this
                    // function returns true, shut down this node (which
                    // will shut down the gossip nodes since they are
                    // supervised by this node.
                    if (update(
                        ((Round<V>) message.payload).round,
                        ((Round<V>) message.payload).data,
                        sender()
                    )) {
                        context().stop(self());
                        context().parent().tell(poisonPill, self());
                    }
                    break;
            }
        }
        // An invalid message was sent - handle it accordingly.
        else { unhandled(rawMessage); }
    }

    /**
     * Returns the node type to construct when building the gossip system.
     * This method is defined this way to enforce that a pair of Gossip/Node
     * classes is defined to support a single problem. The generics match the
     * generics of this function, to enforce compile time compatibility between
     * this set of classes.
     *
     * @return The node type to use when constructing the system.
     */
    public abstract Class<? extends Node<I,U,V>> nodeType();

    /**
     * Initializes the gossip system. Optional override point that will
     * be called once the system is fully initialized, so that additional
     * setup can be done for the specific system.
     */
    public void init() {}

    /**
     * Process incoming round information to determine if the gossip system
     * should continue to run. Provides relevant information about
     * each incoming request so that the system can monitor its children
     * to determine if an acceptable end state has been reached.
     *
     * @param round The round of the incoming update.
     * @param data  The data associated with the round.
     * @param node  The node that reported the update information.
     * @return True if the end state has been reached, triggering a system
     *         shutdown.
     * @throws Exception The update reports an impossible state.
     */
    public abstract boolean update(Integer round, V data, ActorRef node) throws  Exception;
}
