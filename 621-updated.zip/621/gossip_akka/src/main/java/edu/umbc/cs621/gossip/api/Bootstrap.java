package edu.umbc.cs621.gossip.api;

import akka.actor.ActorSystem;
import akka.actor.Props;
import akka.actor.UntypedActor;
import akka.actor.UntypedActorFactory;
import com.google.common.collect.Lists;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Random;

/**
 * @author Colin Taylor
 * @version 1.0
 */
@Component
public class Bootstrap implements ApplicationContextAware {
    private static Logger log = LoggerFactory.getLogger(Bootstrap.class);

    @Resource
    private String systemName;

    @Autowired
    private ActorSystem actorSystem;

    @Bean
    public ActorSystem actorSystem() {
        log.info("Creating actor system with name {}", systemName);
        return ActorSystem.create(systemName);
    }

    private ApplicationContext context;

    public static void main(String[] args) {
        // We need one argument - the name of the client
        if(args.length < 1) {
            System.err.println("java -jar gossip.jar <name>");
            System.exit(1);
        }

        // Run the bootstrap method in client mode
        Bootstrap.run(null, new String[] {"client"}, args[0],
                      null, null, null, null, null, null, null);

        // Finished execution - shutdown cleanly
        System.exit(0);
    }

    public static void run(Class<? extends UntypedActor> klas, String[] activeProfiles,
        String systemName, Long seed, Integer numNodes, Integer numFragments,
        Float probability, Integer fragmentSize, Float fragmentMin,
        Float fragmentMax) {

        // Create a new context
        log.info("Building application context");
        AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();

        // Register required dynamic beans
        Random generator = (seed != null) ? new Random(seed) : new Random();
        ConfigurableListableBeanFactory bf = ctx.getBeanFactory();
        bf.registerSingleton("systemName",   systemName);

        // Register additional dynamic beans if we are running in server mode
        if(!Lists.newArrayList(activeProfiles).contains("client")) {
            log.info("Registering server dynamic beans");
            bf.registerSingleton("generator",    generator);
            bf.registerSingleton("numNodes",     numNodes);
            bf.registerSingleton("numFragments", numFragments);
            bf.registerSingleton("probability",  probability);
            bf.registerSingleton("fragmentSize", fragmentSize);
            bf.registerSingleton("fragmentMin",  fragmentMin);
            bf.registerSingleton("fragmentMax",  fragmentMax);
        }

        // Set the active profiles
        ctx.getEnvironment().setActiveProfiles(activeProfiles);

        // Scan for components
        ctx.scan("edu.umbc");
        ctx.refresh();

        // Start the system
        ctx.getBean(Bootstrap.class).run(klas);
    }

    public void run(final Class<? extends UntypedActor> klas) {
        // Check which mode we are running as, by looking at the active
        // profile set
        if(!Lists.newArrayList(context.getEnvironment().getActiveProfiles()).contains("client")) {
            log.info("Initializing gossip system");
            actorSystem.actorOf(new Props(new UntypedActorFactory() {
                @Override
                public UntypedActor create() throws Exception {
                    return klas.cast(context.getAutowireCapableBeanFactory().createBean(
                        klas,
                        AutowireCapableBeanFactory.AUTOWIRE_BY_TYPE,
                        false
                    ));
                }
            }), "gossip");
        } else log.info("Initializing gossip system client");

        // Wait for the system to finish (blocking)
        log.info("Waiting for actor system termination");
        actorSystem.awaitTermination();
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext)
        throws BeansException {
        this.context = applicationContext;
    }
}
