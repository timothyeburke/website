package edu.umbc.cs621.gossip.api;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public interface DataProvider<T> {
    public T getData(Integer id);
}
