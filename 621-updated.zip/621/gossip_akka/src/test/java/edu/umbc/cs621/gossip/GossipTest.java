package edu.umbc.cs621.gossip;

import edu.umbc.cs621.gossip.api.Bootstrap;
import edu.umbc.cs621.gossip.impl.AverageGossip;
import edu.umbc.cs621.gossip.impl.MedianGossip;
import edu.umbc.cs621.gossip.impl.MinMaxGossip;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;

import java.lang.reflect.Method;

/**
 * @author Colin Taylor
 * @version 1.0
 */
public class GossipTest {

    @Rule
    public TestName name = new TestName();

    @Before
    public void doSetup() {
        // Find the method we are testing
        Method method = null;
        for(Method m : this.getClass().getDeclaredMethods()) {
            if(m.getName().equalsIgnoreCase(name.getMethodName())) {
                method = m;
                break;
            }
        }

        // Extract the setup annotation
        Setup setup = method.getAnnotation(Setup.class);

        // Expand the setup annotation into individual argument
        Integer numNodes     = Integer.parseInt(setup.numNodes());
        Integer numFragments = Integer.parseInt(setup.numFragments());
        Float   probability  = Float.parseFloat(setup.probability());
        Long    seed         = (setup.seed().length() == 0) ? null : Long.parseLong(setup.seed());
        Integer fragmentSize = Integer.parseInt(setup.fragmentSize());
        Float   fragmentMin  = Float.parseFloat(setup.fragmentMin());
        Float   fragmentMax  = Float.parseFloat(setup.fragmentMax());

        // Run the system
        Bootstrap.run(
            setup.actor(),
            setup.profiles(), "main",
            seed, numNodes, numFragments,
            probability, fragmentSize, fragmentMin, fragmentMax
        );
    }

//    @Test @Setup(
//        actor        = MinMaxGossip.class,
//        profiles     = {"local", "uniform", "fullyConnected"},
//        probability  = "0.7",
//        numNodes     = "2000",
//        numFragments = "3000"
//    )
//    public void minMax_70_2000_3000() {}
//
//    @Test @Setup(
//        actor        = AverageGossip.class,
//        profiles     = {"local", "uniform", "fullyConnected"},
//        probability  = "0.7",
//        numNodes     = "1000",
//        numFragments = "1000"
//    )
//    public void average_70_2000_3000() {}

//    @Test @Setup(
//        actor        = MedianGossip.class,
//        profiles     = {"local", "uniform", "fullyConnected"},
//        probability  = "0.7",
//        numNodes     = "10",
//        numFragments = "10"
//    )
//    public void median_70_100_100() {}
}
