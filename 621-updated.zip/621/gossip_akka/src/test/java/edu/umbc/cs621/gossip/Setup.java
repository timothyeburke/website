package edu.umbc.cs621.gossip;

import akka.actor.UntypedActor;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * @author Colin Taylor
 * @version 1.0
 */
@Retention(RUNTIME)
@Target({ElementType.METHOD})
@Documented
public @interface Setup {
    public Class<? extends UntypedActor> actor();
    public String[] profiles();
    public String  numNodes();
    public String  numFragments();
    public String  probability();
    public String  seed()         default "";
    public String  fragmentSize() default "5";
    public String  fragmentMin()  default "0.0";
    public String  fragmentMax()  default "300.0";
}
